//
//  PingOne.h
//  PingOne
//
//  Created by Ping Identity on 3/12/19.
//  Copyright © 2019 Ping Identity. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PingOne.
FOUNDATION_EXPORT double PingOneVersionNumber;

//! Project version string for PingOne.
FOUNDATION_EXPORT const unsigned char PingOneVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PingOne/PublicHeader.h>


